﻿using ExpenseManagement.Auth;
using ExpenseManagement.DTOs;
using ExpenseManagement.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ExpenseManagement.Controllers
{
    public class ExpenseController : Controller
    {
        ExpenseDBEntities1 db = new ExpenseDBEntities1();
        public Expens Convert(ExpensDTO e)
        {
            return new Expens()
            {
                Amount = e.Amount,
                Date = e.Date,
                Category = e.Category,
            };
        }




        [HttpGet]
        public ActionResult Create()
        {
            return View(new ExpensDTO());
        }
        [HttpPost]
        public ActionResult Create(ExpensDTO e)
        {
            if (ModelState.IsValid)
            {
                var efObj = Convert(e);
                db.Expenses.Add(efObj);
                efObj.Date = DateTime.Now;
                db.SaveChanges();


                return RedirectToAction("Index", "Home");
            }

            return View(e);
        }
        public ActionResult List()
        {
            var data = db.Expenses.ToList();
            return View(data);
        }


        [AdminAccess]
        public ActionResult Delete(int IdExpenseId)
        {
            var et = db.Expenses.Find(IdExpenseId);
            db.Expenses.Remove(et);
            db.SaveChanges();
            return RedirectToAction("List", "Student");
        }

    }
}