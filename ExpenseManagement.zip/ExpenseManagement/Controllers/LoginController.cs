﻿using ExpenseManagement.DTOs;
using ExpenseManagement.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ExpenseManagement.Controllers
{
    public class LoginController : Controller
    {
        ExpenseDBEntities1 db = new ExpenseDBEntities1();
        // GET: Login


        [HttpGet]
        public ActionResult Index()
        {
            return View(new LoginDTO());
        }



        [HttpPost]
        public ActionResult Index(LoginDTO log)
        {
            if (ModelState.IsValid)
            {

                var user = (from u in db.Users
                            where u.Email.Equals(log.Email)
                            && u.Password.Equals(log.Password)
                            select u).SingleOrDefault();


                if (user != null)
                {
                    Session["user"] = user;
                    return RedirectToAction("List", "Expense");
                }


            }
            return View(log);

        }
    }
}