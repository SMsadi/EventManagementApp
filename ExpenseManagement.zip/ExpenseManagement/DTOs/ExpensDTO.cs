﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ExpenseManagement.DTOs
{
    public class ExpensDTO
    {
        [Required(ErrorMessage = "Amount Required")]
        [Range(1, 50000, ErrorMessage = "Please enter a valid Amount, Amount can not exceed 50,000 Tk")]
        public double Amount { get; set; }
        public System.DateTime Date { get; set; }

        [Required(ErrorMessage = "Category Required")]
        [Range(1, 3, ErrorMessage = "Please enter a valid Category")]
        public string Category { get; set; }
    }
}